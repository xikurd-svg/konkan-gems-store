"use client";

import React, { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { motion, AnimatePresence } from "framer-motion";

const RATE_MIN = 1450;
const RATE_MAX = 1500;
const KURDISH_DIGITS = ["۰", "۱", "۲", "۳", "۴", "۵", "۶", "۷", "۸", "۹"];
const STORAGE_LANG = "konkan_lang";
const STORAGE_USER = "konkan_user";
const STORAGE_ORDER_COUNT = "konkan_order_count";

const gemPackages = [
  { gems: 100, price: 0.99, bonus: null, popular: false },
  { gems: 500, price: 4.99, bonus: null, popular: false },
  { gems: 950, price: 8.99, bonus: "+5% Bonus", popular: true },
  { gems: 2250, price: 19.99, bonus: "+12% Bonus", popular: false },
  { gems: 4800, price: 39.99, bonus: "+20% Bonus", popular: false },
  { gems: 10800, price: 79.99, bonus: "+35% Bonus", popular: false },
];

const paymentMethods = [
  { key: "fib", title: "FIB", icon: "bank", number: "0750 117 3143", holder: "KonKan Payments", accent: "rgba(56,189,248,.10)" },
  { key: "fastpay", title: "FastPay", icon: "wallet", number: "0750 117 3143", holder: "KonKan Payments", accent: "rgba(16,185,129,.10)" },
];

const emptyUser = { fullName: "", email: "", phone: "", password: "" };

const content = {
  en: {
    storeBadge: "Official KonKan Shop",
    navHome: "Home",
    navEvents: "KonKan Events",
    navHelp: "Help Center",
    signIn: "Sign in",
    signUp: "Create Account",
    signOut: "Logout",
    profile: "Profile",
    settings: "Settings",
    myOrders: "My Orders",
    homeTitle: "KonKan Lobby",
    homeText: "A modern landing page for KonKan. Showcase your main banner, trailer, updates, and featured game card here before sending players to the Gems shop.",
    homeMediaTitle: "Home Banner / Video Area",
    homeMediaSub: "Replace this area later with a KonKan image or video. The layout is ready for future updates.",
    openShop: "Open Gems Shop",
    browseGames: "Browse Games",
    allGames: "All Games",
    allGamesSub: "KonKan is the current featured game. Click the card to open the Gems shop.",
    official: "Official",
    gems: "Gems",
    gameCardSub: "Fast top-up flow, clean checkout, and simple order review.",
    liveNow: "Today & Time",
    liveRate: "USD → IQD Rate",
    autoRefresh: "Auto updated daily",
    currentOrders: "Orders Sent",
    lang: "Language",
    packages: "Gems Packages",
    packagesSub: "Pick the Gems package you want, then set how many units you need.",
    quantity: "Quantity",
    perPack: "Per pack",
    selected: "Selected",
    select: "Select",
    noBonus: "No bonus",
    popular: "Most Popular",
    orderReview: "Order Review",
    reviewSub: "Check your package, quantity, payment method, and totals before sending.",
    paymentMethod: "Payment Method",
    package: "Package",
    subtotal: "Subtotal",
    totalIqd: "Total in IQD",
    paymentTitle: "Payment Methods",
    paymentSub: "Choose the payment method you will use, then send the exact amount shown in the totals.",
    copy: "Copy",
    profileTitle: "Profile & Settings",
    profileSub: "Saved information is used in the order form.",
    playerId: "KonKan Player ID",
    username: "Username",
    contact: "Contact Info",
    phone: "Mobile Number",
    email: "Email",
    fullName: "Full Name",
    password: "Password",
    saveProfile: "Save Profile",
    orderFormTitle: "Submit Your Order",
    orderFormSub: "Complete the form carefully before sending your order.",
    notes: "Extra Notes",
    notesPlaceholder: "Optional note",
    uploadText: "Upload your payment screenshot",
    uploadSub: "PNG, JPG, or JPEG",
    chooseFile: "Choose File",
    submit: "Submit Order",
    submitting: "Submitting...",
    missingFields: "Please complete Player ID, Username, and Contact Info.",
    missingFile: "Please upload a payment screenshot.",
    success: "Order submitted successfully.",
    failed: "Something went wrong while sending the order.",
    webhookInfo: "Order summary includes email, phone, player ID, quantity, totals, and order count.",
    notesTitle: "Shop Notes",
    noteCards: [
      ["Clean checkout", "Choose the package, increase quantity, and review totals before submitting."],
      ["Simple tracking", "Orders count updates locally every time a new request is submitted."],
      ["Safe flow", "Use only official payment methods and keep your payment proof clear."],
    ],
    eventsTitle: "KonKan Events",
    eventsText: "There are no active events right now. Future KonKan events, tournaments, and offers will appear here later.",
    eventsSubText: "Nothing is available at the moment. Please check back later for upcoming content.",
    helpTitle: "Help Center",
    helpText: "Find quick answers about the KonKan store, how to buy Gems, and important safety notes.",
    helpCategories: [
      {
        title: "What is the KonKan Store?",
        body: "The KonKan Store is the official place to view KonKan Gems packages, review prices, choose quantity, and send an order request in a clean and simple flow.",
      },
      {
        title: "How do I buy Gems?",
        body: "Open the KonKan shop, choose a Gems package, set the quantity you want, pick your payment method, upload payment proof, and then submit the order form with your player details.",
      },
      {
        title: "Important Notes",
        body: "Stay away from fake purchases, unofficial payment numbers, and edited payment screenshots. Always use the official KonKan Store and keep your information correct before submitting an order.",
      },
    ],
    authTitle: "Account",
    authText: "Sign in or create an account from the header. Your account stays visible across all pages.",
    createSuccess: "Account created successfully.",
    loginSuccess: "Logged in successfully.",
    logoutSuccess: "Logged out successfully.",
    accountRequired: "Please sign in first.",
    close: "Close",
  },
  ku: {
    storeBadge: "فرۆشگای فەرمی KonKan",
    navHome: "سەرەتا",
    navEvents: "ڕووداوەکانی KonKan",
    navHelp: "یارمەتی",
    signIn: "چوونەژوورەوە",
    signUp: "درووستکردنی ئەکاونت",
    signOut: "چوونەدەرەوە",
    profile: "پرۆفایل",
    settings: "ڕێکخستنەکان",
    myOrders: "داواکارییەکانم",
    homeTitle: "لۆبیی KonKan",
    homeText: "ئەمە پەیجی سەرەکیی KonKan ـە. لێرە دەتوانیت banner، ڤیدیۆ، نوێکاری، و کارتی یاریی سەرەکی دابنێیت پێش ئەوەی یاریزان بنێریت بۆ فرۆشگای گەوهەر.",
    homeMediaTitle: "شوێنی banner / ڤیدیۆی هۆم",
    homeMediaSub: "دواتر دەتوانیت ئەم شوێنە بە وێنە یان ڤیدیۆی KonKan بگۆڕیت بێ ئەوەی دیزاینەکە تێک بچێت.",
    openShop: "کردنەوەی فرۆشگای گەوهەر",
    browseGames: "بینینی یاریەکان",
    allGames: "هەموو یاریەکان",
    allGamesSub: "ئێستا تەنها KonKan ئامادەیە. کرتە لەسەر کارتەکە بکە بۆ چوونە بەشی گەوهەر.",
    official: "فەرمی",
    gems: "گەوهەر",
    gameCardSub: "ڕێڕەوی خێرا بۆ top-up، checkout ی پاک، و پوختەی داواکاری بە شێوەیەکی سادە.",
    liveNow: "بەروار و کات",
    liveRate: "ڕێژی USD → IQD",
    autoRefresh: "ڕۆژانە خۆکارانە نوێ دەبێتەوە",
    currentOrders: "ژمارەی داواکاری",
    lang: "زمان",
    packages: "پاکێجەکانی گەوهەر",
    packagesSub: "پاکێجەکە هەڵبژێرە، پاشان ژمارەی ئەو دانەیە دیاری بکە کە دەتەوێت بیکڕیت.",
    quantity: "ژمارە",
    perPack: "بۆ هەر پاکێجێک",
    selected: "هەڵبژێردراو",
    select: "هەڵبژێرە",
    noBonus: "بۆنوسی نییە",
    popular: "زۆرترین هەڵبژاردن",
    orderReview: "پوختەی داواکاری",
    reviewSub: "پێش ناردن پاکێج، ژمارە، شێوازی پارەدان و کۆی گشتی بسەلمێنە.",
    paymentMethod: "شێوازی پارەدان",
    package: "پاکێج",
    subtotal: "کۆی یەکەم",
    totalIqd: "کۆی گشتی بە دینار",
    paymentTitle: "شێوازەکانی پارەدان",
    paymentSub: "ئەو شێوازە هەڵبژێرە کە دەتەوێت پێی پارە بنێریت، پاشان هەمان بڕی ڕاست بنێرە.",
    copy: "کۆپی",
    profileTitle: "پرۆفایل و ڕێکخستنەکان",
    profileSub: "زانیارییە پاشەکەوتکراوەکانت لە فۆڕمی داواکاری بەکاردێن.",
    playerId: "Player ID ـی KonKan",
    username: "ناوی یوزەر",
    contact: "زانیاریی پەیوەندی",
    phone: "ژمارەی مۆبایل",
    email: "ئیمەیڵ",
    fullName: "ناوی تەواو",
    password: "وشەی نهێنی",
    saveProfile: "پاشەکەوتکردنی پرۆفایل",
    orderFormTitle: "ناردنی داواکاری",
    orderFormSub: "پێش ناردنی داواکاری، فۆڕمەکە بە وردی پڕبکەوە.",
    notes: "تێبینی زیادە",
    notesPlaceholder: "تێبینییەکی هەڵبژاردە",
    uploadText: "وێنەی پارەدانەکەت باربکە",
    uploadSub: "PNG، JPG، یان JPEG",
    chooseFile: "فایل هەڵبژێرە",
    submit: "ناردنی داواکاری",
    submitting: "لە ناردندایە...",
    missingFields: "تکایە Player ID، ناوی یوزەر و زانیاریی پەیوەندی پڕبکەوە.",
    missingFile: "تکایە وێنەی پارەدانەکە باربکە.",
    success: "داواکارییەکەت بە سەرکەوتوویی نێردرا.",
    failed: "لە ناردنی داواکارییەکەدا کێشەیەک ڕوویدا.",
    webhookInfo: "پوختەی داواکاری ئیمەیڵ، مۆبایل، Player ID، ژمارە، کۆی گشتی و ژمارەی داواکاری دەگرێتەوە.",
    notesTitle: "تێبینییەکانی فرۆشگا",
    noteCards: [
      ["checkout ی ڕێک", "پاکێج هەڵبژێرە، ژمارە زیاد بکە، و پێش ناردن کۆی گشتی ببینە."],
      ["چاودێری سادە", "ژمارەی داواکاری خۆکارانە لە local زیاد دەبێت هەرکات داواکاری نوێ بنێریت."],
      ["ڕێڕەوی پارێزراو", "تەنها شێوازە فەرمییەکانی پارەدان بەکاربهێنە و وێنەی پارەدانەکەت ڕوون بێت."],
    ],
    eventsTitle: "ڕووداوەکانی KonKan",
    eventsText: "ئێستا هیچ ڕووداوێکی چالاک بەردەست نییە. لە داهاتوودا ڕووداو، پاڵەوانێتی، و ئۆفەری KonKan لێرە زیاد دەکرێت.",
    eventsSubText: "لەم ساتەدا هیچ ناوەڕۆکێک بەردەست نییە. تکایە دواتر سەردانی بکە بۆ زانیاریی نوێ.",
    helpTitle: "یارمەتی",
    helpText: "وەڵامی خێرا بدۆزەرەوە دەربارەی فرۆشگای KonKan، چۆنیەتی کڕینی گەوهەر، و تێبینییە پارێزراوەکان.",
    helpCategories: [
      {
        title: "فرۆشگای KonKan چییە؟",
        body: "فرۆشگای KonKan شوێنی فەرمییە بۆ بینینی پاکێجەکانی گەوهەر، نرخیان، هەڵبژاردنی ژمارە، و ناردنی داواکاری بە شێوەیەکی پاک و سادە.",
      },
      {
        title: "چۆن گەوهەر بکڕم؟",
        body: "فرۆشگای KonKan بکەرەوە، پاکێجی گەوهەر هەڵبژێرە، ژمارە دیاری بکە، شێوازی پارەدان دیاری بکە، وێنەی پارەدانەکەت باربکە، و لە کۆتاییدا فۆڕمی داواکاری بنێرە.",
      },
      {
        title: "تێبینییە گرنگەکان",
        body: "دووربە لە کڕینی فەیک، ژمارەی پارەدانی نافەرمی، و وێنەی پارەدانی دەستکاری کراو. تەنها فرۆشگای فەرمیی KonKan بەکاربهێنە و زانیارییەکانت بە وردی پڕبکەوە.",
      },
    ],
    authTitle: "ئەکاونت",
    authText: "لێرە لە هێدەری سەرەوە بچۆ ژوورەوە یان ئەکاونت درووست بکە. ئەکاونتەکەت لە هەموو پەیجەکاندا دیار دەبێت.",
    createSuccess: "ئەکاونتەکە بە سەرکەوتوویی درووست کرا.",
    loginSuccess: "بە سەرکەوتوویی چوویتە ژوورەوە.",
    logoutSuccess: "بە سەرکەوتوویی چوویتە دەرەوە.",
    accountRequired: "تکایە سەرەتا بچۆرە ژوورەوە.",
    close: "داخستن",
  },
};

function getDailyRate(date = new Date()) {
  const key = `${date.getUTCFullYear()}-${date.getUTCMonth() + 1}-${date.getUTCDate()}`;
  let hash = 0;
  for (let i = 0; i < key.length; i += 1) hash = (hash * 31 + key.charCodeAt(i)) >>> 0;
  return RATE_MIN + (hash % (RATE_MAX - RATE_MIN + 1));
}

function Icon({ name, className = "icon18" }) {
  const common = { viewBox: "0 0 24 24", fill: "none", xmlns: "http://www.w3.org/2000/svg", className, "aria-hidden": true };
  switch (name) {
    case "gem":
      return <svg {...common}><path d="M7 4h10l4 5-9 11L3 9l4-5Z" fill="url(#g1)" stroke="rgba(255,255,255,.55)"/><path d="M7 4l5 16 5-16" stroke="rgba(255,255,255,.45)"/><path d="M3 9h18" stroke="rgba(255,255,255,.35)"/><defs><linearGradient id="g1" x1="3" y1="4" x2="21" y2="20" gradientUnits="userSpaceOnUse"><stop stopColor="#7dd3fc"/><stop offset="1" stopColor="#2563eb"/></linearGradient></defs></svg>;
    case "calendar":
      return <svg {...common}><rect x="3.5" y="5" width="17" height="15" rx="3" fill="rgba(203,157,32,.12)" stroke="rgba(203,157,32,.55)"/><path d="M7 3.5v3M17 3.5v3M3.5 9.5h17" stroke="rgba(255,255,255,.8)" strokeWidth="1.5" strokeLinecap="round"/></svg>;
    case "rate":
      return <svg {...common}><path d="M4 16 9 11l4 4 7-8" stroke="rgba(203,157,32,.95)" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/><path d="M17 7h3v3" stroke="rgba(203,157,32,.95)" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/></svg>;
    case "lang":
      return <svg {...common}><circle cx="12" cy="12" r="8" stroke="rgba(203,157,32,.78)"/><path d="M4.5 12h15M12 4a13.5 13.5 0 0 1 0 16M12 4a13.5 13.5 0 0 0 0 16" stroke="rgba(203,157,32,.78)" strokeWidth="1.4" strokeLinecap="round"/></svg>;
    case "orders":
      return <svg {...common}><rect x="5" y="4.5" width="14" height="15" rx="3" stroke="rgba(203,157,32,.8)"/><path d="M8.5 8h7M8.5 12h7M8.5 16h4" stroke="rgba(203,157,32,.8)" strokeWidth="1.6" strokeLinecap="round"/></svg>;
    case "user":
      return <svg {...common}><circle cx="12" cy="8" r="3.2" fill="rgba(203,157,32,.18)" stroke="rgba(203,157,32,.7)"/><path d="M5 19c1.4-3 4-4.5 7-4.5S17.6 16 19 19" stroke="rgba(203,157,32,.8)" strokeWidth="1.8" strokeLinecap="round"/></svg>;
    case "bank":
      return <svg {...common}><path d="M4 9 12 4l8 5" stroke="rgba(103,232,249,.9)" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"/><path d="M6 10.5V18M10 10.5V18M14 10.5V18M18 10.5V18M4.5 19.5h15" stroke="rgba(103,232,249,.7)" strokeWidth="1.5" strokeLinecap="round"/></svg>;
    case "wallet":
      return <svg {...common}><rect x="3.5" y="6.5" width="17" height="11" rx="3" fill="rgba(16,185,129,.15)" stroke="rgba(74,222,128,.55)"/><path d="M15 10.25h5.5v3.5H15a1.75 1.75 0 1 1 0-3.5Z" fill="rgba(74,222,128,.12)" stroke="rgba(74,222,128,.55)"/><circle cx="16.8" cy="12" r=".8" fill="rgba(255,255,255,.95)"/></svg>;
    case "upload":
      return <svg {...common}><path d="M12 15V6" stroke="rgba(103,232,249,.95)" strokeWidth="1.8" strokeLinecap="round"/><path d="m8.5 9.5 3.5-3.5 3.5 3.5" stroke="rgba(103,232,249,.95)" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/><rect x="4" y="15.5" width="16" height="4.5" rx="2.25" fill="rgba(34,211,238,.12)" stroke="rgba(103,232,249,.45)"/></svg>;
    case "sparkle":
      return <svg {...common}><path d="M12 3.5 13.8 8.2 18.5 10 13.8 11.8 12 16.5 10.2 11.8 5.5 10l4.7-1.8L12 3.5Z" fill="rgba(203,157,32,.85)"/><path d="M18 4.5 18.7 6.3 20.5 7 18.7 7.7 18 9.5 17.3 7.7 15.5 7l1.8-.7L18 4.5Z" fill="rgba(255,255,255,.8)"/></svg>;
    case "chevron":
      return <svg {...common}><path d="m9 6 6 6-6 6" stroke="rgba(203,157,32,.95)" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/></svg>;
    case "close":
      return <svg {...common}><path d="M6 6l12 12M18 6 6 18" stroke="rgba(255,255,255,.9)" strokeWidth="1.8" strokeLinecap="round"/></svg>;
    default:
      return <svg {...common}><circle cx="12" cy="12" r="8" fill="rgba(203,157,32,.18)" stroke="rgba(203,157,32,.55)"/></svg>;
  }
}

function toKurdishDigits(value) {
  return String(value).replace(/[0-9]/g, (digit) => KURDISH_DIGITS[Number(digit)]);
}
function displayNumber(value, lang) {
  return lang === "ku" ? toKurdishDigits(value) : String(value);
}
function formatMoney(value, lang, currency = "USD") {
  const formatted = new Intl.NumberFormat(lang === "ku" ? "ckb-IQ" : "en-US", {
    minimumFractionDigits: currency === "USD" ? 2 : 0,
    maximumFractionDigits: currency === "USD" ? 2 : 0,
  }).format(value);
  const result = currency === "USD" ? `$${formatted}` : `${formatted} IQD`;
  return lang === "ku" ? toKurdishDigits(result) : result;
}
function getNowParts(lang) {
  const now = new Date();
  const dateText = new Intl.DateTimeFormat(lang === "ku" ? "ckb-IQ" : "en-US", {
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric",
  }).format(now);
  const timeText = new Intl.DateTimeFormat(lang === "ku" ? "ckb-IQ" : "en-US", {
    hour: "numeric",
    minute: "2-digit",
    second: "2-digit",
  }).format(now);
  return {
    dateText: lang === "ku" ? toKurdishDigits(dateText) : dateText,
    timeText: lang === "ku" ? toKurdishDigits(timeText) : timeText,
  };
}

function GlobalStyles() {
  return (
    <style jsx global>{`
      :root{
        --kk-gold:#CB9D20;
        --kk-brown:#241D0F;
        --kk-panel:#0e1118;
        --kk-panel-2:#121725;
        --kk-text:#f8fafc;
        --kk-muted:#a7b1c2;
        --kk-border:rgba(203,157,32,.18);
        --kk-shadow:0 24px 60px rgba(0,0,0,.30);
        --kk-radius:26px;
      }
      *{box-sizing:border-box}
      html,body{margin:0;padding:0;background:#08090d;color:var(--kk-text);font-family:Inter,Arial,sans-serif}
      body{overflow-x:hidden}
      a{text-decoration:none;color:inherit}
      button,input,textarea{font:inherit}
      .icon18{width:18px;height:18px;display:inline-block;flex:0 0 auto}
      .page-shell{
        min-height:100vh;
        background:
          radial-gradient(circle at top left, rgba(203,157,32,.10), transparent 24%),
          radial-gradient(circle at top right, rgba(203,157,32,.08), transparent 24%),
          linear-gradient(180deg, #07090d, #0b0e14 40%, #07090d);
      }
      .container{width:100%;max-width:none;margin:0;padding:18px clamp(14px,2vw,28px) 70px;position:relative}
      .glow{position:fixed;border-radius:999px;pointer-events:none;filter:blur(95px);opacity:.56}
      .g1{width:280px;height:280px;background:rgba(203,157,32,.10);top:-80px;left:12%}
      .g2{width:240px;height:240px;background:rgba(203,157,32,.09);top:30%;right:-60px}
      .g3{width:260px;height:260px;background:rgba(36,29,15,.55);bottom:0;left:-60px}
      .surface,.hero-shell,.panel,.note-card,.game-card,.top-card,.topbar{backdrop-filter:blur(16px);background:rgba(255,255,255,.035);border:1px solid var(--kk-border);box-shadow:var(--kk-shadow)}
      .topbar{position:sticky;top:10px;z-index:25;margin-bottom:18px;border-radius:30px;padding:14px 18px;display:flex;align-items:center;justify-content:space-between;gap:18px;background:linear-gradient(180deg, rgba(11,10,8,.92), rgba(12,15,21,.75))}
      .brand-wrap{display:flex;align-items:center;gap:16px;min-width:0}
      .brand-badge{display:inline-flex;align-items:center;gap:10px;padding:12px 16px;border-radius:999px;background:rgba(203,157,32,.10);border:1px solid rgba(203,157,32,.24);color:#f7de94;font-size:12px;font-weight:900;letter-spacing:.16em;text-transform:uppercase;white-space:nowrap}
      .topnav{display:flex;align-items:center;gap:8px;flex-wrap:wrap}
      .nav-link{padding:12px 14px;border-radius:14px;color:#d7dde8;font-weight:700;transition:.2s ease}
      .nav-link:hover,.nav-link.active{background:rgba(203,157,32,.10);color:#fff}
      .header-right{display:flex;align-items:center;gap:12px;flex-wrap:wrap;justify-content:flex-end}
      .header-info-grid{display:grid;grid-template-columns:repeat(3,minmax(138px,1fr));gap:12px}
      .top-card{border-radius:20px;padding:12px 14px;background:rgba(9,10,15,.78);display:flex;align-items:center;gap:12px;min-height:82px;min-width:132px}
      .top-card-icon{width:42px;height:42px;border-radius:14px;display:grid;place-items:center;background:rgba(203,157,32,.10);border:1px solid rgba(203,157,32,.18);flex:0 0 auto}
      .top-card-label{font-size:11px;text-transform:uppercase;letter-spacing:.15em;color:#9ba7bd;font-weight:800}
      .top-card-main{margin-top:4px;font-size:15px;font-weight:900;color:#fff;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
      .top-card-sub{margin-top:4px;font-size:12px;color:#98a2b5;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
      .sign-btn,.dropdown-item,.cta-btn,.mini-btn,.ghost-btn,.submit-btn,.copy-btn,.qty-btn,.faq-head{transition:.2s ease}
      .sign-btn{display:inline-flex;align-items:center;gap:10px;padding:14px 16px;border-radius:18px;background:linear-gradient(135deg, rgba(203,157,32,.20), rgba(36,29,15,.92));border:1px solid rgba(203,157,32,.28);color:#fff;font-weight:800;cursor:pointer;min-height:82px}
      .sign-btn:hover{transform:translateY(-1px)}
      .sign-dropdown{position:absolute;top:calc(100% + 10px);right:0;width:240px;border-radius:20px;padding:10px;background:rgba(10,11,16,.94);border:1px solid rgba(203,157,32,.22);box-shadow:var(--kk-shadow)}
      .dropdown-item{display:flex;align-items:center;gap:10px;width:100%;padding:12px 14px;border-radius:14px;background:transparent;border:0;color:#e8edf6;cursor:pointer;text-align:start}
      .dropdown-item:hover{background:rgba(203,157,32,.08)}
      .hero-shell{border-radius:34px;overflow:hidden;margin-bottom:24px}
      .hero-grid{display:grid;grid-template-columns:1.05fr .95fr}
      .hero-left{padding:30px;display:flex;flex-direction:column;gap:18px;background:linear-gradient(180deg, rgba(36,29,15,.35), rgba(11,16,24,.90))}
      .hero-topstrip{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px}
      .stat-box{border-radius:18px;padding:14px;background:rgba(36,29,15,.34);border:1px solid rgba(203,157,32,.12)}
      .stat-row-head{display:flex;align-items:center;gap:8px;margin-bottom:8px}
      .stat-label{font-size:11px;color:#c6af69;text-transform:uppercase;letter-spacing:.16em;font-weight:700}
      .stat-value{margin-top:8px;font-size:15px;font-weight:800;color:#f8fafc}
      .rate-sub{margin-top:6px;font-size:12px;color:#b5bccb;line-height:1.65}
      .hero-title{margin:0;font-size:clamp(2.8rem,5vw,4.5rem);line-height:1.02;letter-spacing:-.05em;font-weight:900}
      .hero-title .accent{color:var(--kk-gold)}
      .hero-text{max-width:700px;color:#d4d9e3;line-height:1.9;font-size:15px;margin:0}
      .hero-cta-row{display:flex;gap:12px;flex-wrap:wrap}
      .cta-btn{border:0;border-radius:16px;padding:13px 18px;font-weight:800;cursor:pointer}
      .cta-btn.primary{background:linear-gradient(135deg, var(--kk-gold), #a97d11);color:#0f1117}
      .cta-btn.secondary{background:rgba(255,255,255,.04);color:#e2e8f0;border:1px solid rgba(203,157,32,.18)}
      .hero-right{position:relative;min-height:460px;overflow:hidden}
      .hero-media{width:100%;height:100%;object-fit:cover;display:block;opacity:.94}
      .hero-overlay{position:absolute;inset:0;background:linear-gradient(90deg, rgba(9,10,15,.18), rgba(9,10,15,.50))}
      .media-placeholder{position:absolute;left:32px;right:32px;bottom:32px;border-radius:28px;background:rgba(10,12,17,.70);border:1px solid rgba(203,157,32,.18);padding:20px;z-index:2}
      .media-title{font-size:26px;font-weight:900}
      .media-sub{margin-top:8px;color:#d4d9e3;line-height:1.8;max-width:420px}
      .panel{border-radius:30px;padding:24px}
      .section-head{display:flex;align-items:flex-end;justify-content:space-between;gap:16px;margin-bottom:18px}
      .section-title{margin:0;font-size:clamp(1.8rem,3vw,2.5rem);line-height:1.1;font-weight:900}
      .section-sub{margin-top:8px;color:#a9b2c3;line-height:1.8}
      .games-grid,.packages-grid,.payment-grid,.note-grid,.review-grid,.field-grid,.inline-grid,.cards-grid{display:grid;gap:16px}
      .games-grid{grid-template-columns:repeat(1,minmax(0,320px))}
      .cards-grid{grid-template-columns:repeat(3,minmax(0,1fr))}
      .inline-grid{grid-template-columns:repeat(2,minmax(0,1fr))}
      .game-card{border-radius:28px;overflow:hidden;cursor:pointer;transition:.24s ease;background:linear-gradient(180deg, rgba(36,29,15,.45), rgba(9,12,19,.88))}
      .game-card:hover{transform:translateY(-4px)}
      .game-cover{aspect-ratio:1.14/1;position:relative;overflow:hidden}
      .game-cover img{width:100%;height:100%;object-fit:cover;display:block}
      .game-overlay{position:absolute;inset:0;background:linear-gradient(180deg, rgba(7,11,18,0), rgba(7,11,18,.88))}
      .game-content{padding:16px 18px 18px}
      .game-title{font-size:22px;font-weight:900}.game-meta{margin-top:6px;color:#d4d9e3}.chip-row{display:flex;gap:10px;flex-wrap:wrap;margin-top:12px}.mini-chip{display:inline-flex;align-items:center;gap:8px;border-radius:999px;padding:8px 12px;background:rgba(203,157,32,.10);border:1px solid rgba(203,157,32,.16);color:#f7de94;font-size:12px;font-weight:800}
      .main-grid{display:grid;grid-template-columns:minmax(0,1fr) 380px;gap:20px;align-items:start}.right-grid{display:grid;gap:18px;position:sticky;top:110px}
      .package-card{text-align:start;border-radius:28px;padding:22px;cursor:pointer;border:1px solid rgba(148,163,184,.14);background:linear-gradient(180deg, rgba(255,255,255,.05), rgba(255,255,255,.03));position:relative}.package-card.active{border-color:rgba(103,232,249,.34);box-shadow:0 0 0 1px rgba(103,232,249,.15),0 24px 60px rgba(0,0,0,.30)}.package-top{display:flex;justify-content:space-between;gap:16px;align-items:flex-start}.gem-chip{width:64px;height:64px;border-radius:22px;padding:1px;background:linear-gradient(180deg, rgba(34,211,238,.55), rgba(14,165,233,.08));box-shadow:inset 0 0 0 1px rgba(34,211,238,.18),0 0 0 1px rgba(34,211,238,.10),0 14px 35px rgba(8,145,178,.12)}.gem-chip-inner{width:100%;height:100%;border-radius:21px;display:grid;place-items:center;background:linear-gradient(180deg, rgba(17,24,39,.98), rgba(11,18,32,.94))}.gem-svg{width:30px;height:30px;filter:drop-shadow(0 0 12px rgba(56,189,248,.35))}.gem-count{font-size:2.7rem;font-weight:900;line-height:1}.gem-label{margin-top:8px;color:#67e8f9;letter-spacing:.22em;text-transform:uppercase;font-weight:800;font-size:14px}.bonus{margin-top:8px;font-weight:700;color:#f8fafc}.bonus.muted{color:#94a3b8}.price-main{font-size:2rem;font-weight:900;color:#a5f3fc}.price-sub{margin-top:6px;color:#cbd5e1}.package-actions{margin-top:18px;display:flex;align-items:center;justify-content:space-between;gap:14px}.qty-box{display:inline-flex;align-items:center;gap:8px;border-radius:18px;padding:8px;background:rgba(255,255,255,.04);border:1px solid rgba(148,163,184,.12)}.qty-btn{width:36px;height:36px;border-radius:12px;border:0;background:rgba(255,255,255,.06);color:#fff;font-size:22px}.qty-num{min-width:32px;text-align:center;font-weight:800}.select-tag,.pop-tag{display:inline-flex;align-items:center;justify-content:center;border-radius:999px;font-weight:800}.select-tag{padding:10px 16px;background:rgba(34,211,238,.12);color:#cffafe;border:1px solid rgba(103,232,249,.22)}.pop-tag{position:absolute;top:14px;right:14px;padding:8px 12px;font-size:12px;background:rgba(37,99,235,.16);color:#bfdbfe;border:1px solid rgba(96,165,250,.28)}
      .method-title{display:flex;align-items:center;gap:10px;font-size:18px;font-weight:800;color:#f8fafc}.method-line{margin-top:8px;line-height:1.55;color:#d4d9e3}.pay-logo{width:58px;height:58px;border-radius:18px;object-fit:cover;flex:0 0 auto;box-shadow:0 12px 28px rgba(0,0,0,.22)}.payment-logo-row{display:flex;align-items:flex-start;gap:14px}.payment-copy-row{display:flex;justify-content:flex-end;margin-top:16px}.copy-btn{min-width:88px;display:inline-flex;justify-content:center}.payment-grid{grid-template-columns:repeat(2,minmax(0,1fr));align-items:stretch}.payment-card{border-radius:24px;padding:18px;border:1px solid rgba(148,163,184,.12);background:rgba(255,255,255,.03);display:flex;flex-direction:column;justify-content:space-between;min-height:220px;position:relative;overflow:hidden}.payment-card.active{border-color:rgba(203,157,32,.30);box-shadow:0 0 0 1px rgba(203,157,32,.12)}.method-head,.review-line{display:flex;justify-content:space-between;gap:12px;align-items:flex-start}.review-grid{padding:8px 0 0}.review-line{padding:14px 0;border-bottom:1px solid rgba(148,163,184,.10)}.review-line:last-child{border-bottom:0}.review-label{color:#aab2c4}.review-value{font-weight:800;color:#fff;text-align:end}.footer-note{margin-top:14px;color:#98a2b5;font-size:13px;line-height:1.8}
      .field-grid{gap:16px}.field label{display:block;font-size:13px;color:#d9dfeb;margin-bottom:8px;font-weight:700}.field input,.field textarea{width:100%;border-radius:16px;background:rgba(255,255,255,.04);border:1px solid rgba(203,157,32,.12);color:#fff;padding:14px 16px;outline:none}.field input:focus,.field textarea:focus{border-color:rgba(203,157,32,.28);box-shadow:0 0 0 3px rgba(203,157,32,.08)}
      .upload-box{border:1px dashed rgba(103,232,249,.24);border-radius:24px;padding:26px;display:grid;place-items:center;text-align:center;background:rgba(255,255,255,.03);cursor:pointer}.upload-box input{display:none}.upload-icon-wrap{width:64px;height:64px;border-radius:20px;display:grid;place-items:center;background:rgba(34,211,238,.08);border:1px solid rgba(103,232,249,.18)}.upload-text{margin-top:16px;font-size:18px;font-weight:800}.upload-sub,.file-name{margin-top:8px;color:#94a3b8}.file-name{word-break:break-word}
      .mini-btn,.ghost-btn,.submit-btn,.copy-btn,.tab-btn{border-radius:14px;padding:12px 16px;font-weight:800;border:0;cursor:pointer}.mini-btn,.submit-btn,.tab-btn.active{background:linear-gradient(135deg, var(--kk-gold), #a97d11);color:#0e1118}.ghost-btn,.copy-btn,.tab-btn{background:rgba(255,255,255,.04);color:#e2e8f0;border:1px solid rgba(203,157,32,.14)}.tab-btn{flex:1}.auth-tabs{display:flex;gap:10px}.submit-btn{width:100%;max-width:320px}.status{margin-top:16px;border-radius:16px;padding:14px 16px;font-weight:700;background:rgba(203,157,32,.10);border:1px solid rgba(203,157,32,.18);color:#f8e7b0}
      .faq-stack{display:grid;gap:14px}.faq-item{border-radius:22px;background:rgba(255,255,255,.03);border:1px solid rgba(203,157,32,.14);overflow:hidden}.faq-head{width:100%;display:flex;align-items:center;justify-content:space-between;gap:14px;padding:18px 20px;background:transparent;border:0;color:#fff;text-align:start;cursor:pointer}.faq-head:hover{background:rgba(203,157,32,.06)}.faq-body{padding:0 20px 18px;color:#d4d9e3;line-height:1.9}.empty-state{text-align:center;padding:60px 24px;background:linear-gradient(180deg, rgba(36,29,15,.34), rgba(10,12,18,.88));border-radius:28px;border:1px solid rgba(203,157,32,.16)}.empty-state h2{margin:0 0 12px;font-size:2rem}.empty-state p{margin:0 auto;max-width:720px;color:#d4d9e3;line-height:1.9}
      .modal-backdrop{position:fixed;inset:0;background:rgba(0,0,0,.55);display:grid;place-items:center;padding:18px;z-index:60}.modal-card{width:min(100%, 480px);border-radius:28px;padding:22px;background:linear-gradient(180deg, rgba(11,11,15,.96), rgba(18,20,29,.96));border:1px solid rgba(203,157,32,.22);box-shadow:var(--kk-shadow)}.modal-head{display:flex;align-items:flex-start;justify-content:space-between;gap:16px;margin-bottom:18px}.close-btn{width:40px;height:40px;border-radius:14px;background:rgba(255,255,255,.05);border:1px solid rgba(203,157,32,.14);display:grid;place-items:center;cursor:pointer}
      @media (max-width: 1260px){.topbar{position:static}.hero-grid,.main-grid{grid-template-columns:1fr}.right-grid{position:static}.header-right{width:100%}.header-info-grid{width:100%;grid-template-columns:repeat(3,minmax(0,1fr))}.hero-right{min-height:380px}}
      @media (max-width: 960px){.topbar{flex-direction:column;align-items:stretch}.brand-wrap{flex-direction:column;align-items:flex-start}.header-right{justify-content:stretch}.header-info-grid{grid-template-columns:1fr}.cards-grid,.payment-grid,.inline-grid,.hero-topstrip,.note-grid{grid-template-columns:1fr}.container{padding:14px 12px 42px}.sign-btn{min-height:unset;width:100%;justify-content:center}.payment-card{min-height:auto}}
    `}</style>
  );
}

function Header({ lang, setLang, t, orderCount, nowParts, usdToIqd, user, onOpenAuth, onLogout }) {
  const pathname = usePathname();
  const [menuOpen, setMenuOpen] = useState(false);
  const navItems = [
    { href: "/", label: t.navHome },
    { href: "/events", label: t.navEvents },
    { href: "/help", label: t.navHelp },
  ];

  return (
    <header className="topbar">
      <div className="brand-wrap">
        <div className="brand-badge"><Icon name="gem" /> {t.storeBadge}</div>
        <nav className="topnav">
          {navItems.map((item) => (
            <Link key={item.href} href={item.href} className={`nav-link ${pathname === item.href ? "active" : ""}`}>
              {item.label}
            </Link>
          ))}
        </nav>
      </div>

      <div className="header-right">
        <div className="header-info-grid">
          <div className="top-card">
            <div className="top-card-icon"><Icon name="calendar" /></div>
            <div>
              <div className="top-card-label">{t.liveNow}</div>
              <div className="top-card-main">{nowParts.timeText}</div>
              <div className="top-card-sub">{nowParts.dateText}</div>
            </div>
          </div>

          <div className="top-card">
            <div className="top-card-icon"><Icon name="orders" /></div>
            <div>
              <div className="top-card-label">{t.currentOrders}</div>
              <div className="top-card-main">{displayNumber(orderCount, lang)}</div>
              <div className="top-card-sub">KonKan</div>
            </div>
          </div>

          <button type="button" className="top-card" onClick={() => setLang((prev) => (prev === "en" ? "ku" : "en"))}>
            <div className="top-card-icon"><Icon name="lang" /></div>
            <div>
              <div className="top-card-label">{t.lang}</div>
              <div className="top-card-main">{lang === "ku" ? "کوردی" : "English"}</div>
              <div className="top-card-sub">{lang === "ku" ? "ژمارەی لوکال" : "Localized digits"}</div>
            </div>
          </button>
        </div>

        <div style={{ position: "relative" }}>
          {user?.email ? (
            <>
              <button type="button" className="sign-btn" onClick={() => setMenuOpen((prev) => !prev)}>
                <Icon name="user" />
                <div style={{ textAlign: "start" }}>
                  <div style={{ fontSize: 13, color: "#f4d98e", fontWeight: 800 }}>{user.fullName || user.email}</div>
                  <div style={{ fontSize: 12, color: "#c4ccda" }}>{user.email}</div>
                </div>
              </button>
              {menuOpen ? (
                <div className="sign-dropdown">
                  <button type="button" className="dropdown-item"><Icon name="user" /> {t.profile}</button>
                  <button type="button" className="dropdown-item"><Icon name="orders" /> {t.myOrders}</button>
                  <button type="button" className="dropdown-item"><Icon name="lang" /> {t.settings}</button>
                  <button type="button" className="dropdown-item" onClick={() => { setMenuOpen(false); onLogout(); }}><Icon name="close" /> {t.signOut}</button>
                </div>
              ) : null}
            </>
          ) : (
            <button type="button" className="sign-btn" onClick={onOpenAuth}>
              <Icon name="user" />
              <span>{t.signIn}</span>
            </button>
          )}
        </div>
      </div>
    </header>
  );
}

function AuthModal({ open, onClose, t, user, setUser, setFlash }) {
  const [mode, setMode] = useState("login");
  const [form, setForm] = useState(emptyUser);

  useEffect(() => {
    if (open) setForm(emptyUser);
  }, [open]);

  if (!open) return null;

  const submit = (e) => {
    e.preventDefault();
    if (!form.email || !form.password) return;
    if (mode === "signup" && !form.fullName) return;
    const nextUser = {
      fullName: form.fullName || form.email.split("@")[0],
      email: form.email,
      phone: form.phone,
      password: form.password,
    };
    setUser(nextUser);
    try {
      localStorage.setItem(STORAGE_USER, JSON.stringify(nextUser));
    } catch {}
    setFlash(mode === "signup" ? t.createSuccess : t.loginSuccess);
    onClose();
  };

  return (
    <AnimatePresence>
      <motion.div className="modal-backdrop" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
        <motion.div className="modal-card" initial={{ y: 18, opacity: 0 }} animate={{ y: 0, opacity: 1 }} exit={{ y: 18, opacity: 0 }}>
          <div className="modal-head">
            <div>
              <div className="section-title" style={{ fontSize: 28 }}>{mode === "login" ? t.signIn : t.signUp}</div>
              <div className="section-sub" style={{ marginTop: 6 }}>{t.authText}</div>
            </div>
            <button type="button" className="close-btn" onClick={onClose}><Icon name="close" /></button>
          </div>

          <div className="auth-tabs">
            <button type="button" className={`tab-btn ${mode === "login" ? "active" : ""}`} onClick={() => setMode("login")}>{t.signIn}</button>
            <button type="button" className={`tab-btn ${mode === "signup" ? "active" : ""}`} onClick={() => setMode("signup")}>{t.signUp}</button>
          </div>

          <form onSubmit={submit} className="field-grid" style={{ marginTop: 16 }}>
            {mode === "signup" ? (
              <div className="field">
                <label>{t.fullName}</label>
                <input value={form.fullName} onChange={(e) => setForm((p) => ({ ...p, fullName: e.target.value }))} />
              </div>
            ) : null}
            <div className="field">
              <label>{t.email}</label>
              <input type="email" value={form.email} onChange={(e) => setForm((p) => ({ ...p, email: e.target.value }))} />
            </div>
            <div className="field">
              <label>{t.password}</label>
              <input type="password" value={form.password} onChange={(e) => setForm((p) => ({ ...p, password: e.target.value }))} />
            </div>
            {mode === "signup" ? (
              <div className="field">
                <label>{t.phone}</label>
                <input value={form.phone} onChange={(e) => setForm((p) => ({ ...p, phone: e.target.value }))} />
              </div>
            ) : null}
            <button type="submit" className="mini-btn">{mode === "login" ? t.signIn : t.signUp}</button>
          </form>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}

function HomePage({ lang, setLang, t, user, setUser, orderCount, usdToIqd, nowParts, onOpenAuth, onLogout }) {
  return (
    <div className="page-shell">
      <GlobalStyles />
      <div className="glow g1" />
      <div className="glow g2" />
      <div className="glow g3" />
      <div className="container">
        <Header lang={lang} setLang={setLang} t={t} orderCount={orderCount} nowParts={nowParts} usdToIqd={usdToIqd} user={user} onOpenAuth={onOpenAuth} onLogout={onLogout} />

        <motion.section className="hero-shell" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.45 }}>
          <div className="hero-grid">
            <div className="hero-left">
              <div className="brand-badge" style={{ width: "fit-content" }}><Icon name="sparkle" /> {t.official}</div>
              <h1 className="hero-title">{t.homeTitle} <span className="accent">KonKan</span></h1>
              <p className="hero-text">{t.homeText}</p>
              <div className="hero-cta-row">
                <Link href="/shop" className="cta-btn primary">{t.openShop}</Link>
                <a href="#all-games" className="cta-btn secondary">{t.browseGames}</a>
              </div>
            </div>

            <div className="hero-right">
              <img src="/home-banner.svg" alt="KonKan" className="hero-media" />
              <div className="hero-overlay" />

            </div>
          </div>
        </motion.section>

        <section className="panel" id="all-games">
          <div className="section-head">
            <div>
              <h2 className="section-title">{t.allGames}</h2>
              <div className="section-sub">{t.allGamesSub}</div>
            </div>
          </div>
          <div className="games-grid">
            <Link href="/shop" className="game-card">
              <div className="game-cover">
                <img src="/konkanvip.png" alt="KonKan" />
                <div className="game-overlay" />
              </div>
              <div className="game-content">
                <div className="game-title">KonKan</div>
                <div className="game-meta">{t.gameCardSub}</div>
                <div className="chip-row">
                  <div className="mini-chip"><Icon name="gem" /> {t.gems}</div>
                  <div className="mini-chip"><Icon name="sparkle" /> {t.official}</div>
                </div>
              </div>
            </Link>
          </div>
        </section>
      </div>
    </div>
  );
}

function ShopPage({ lang, setLang, t, user, setUser, orderCount, setOrderCount, usdToIqd, nowParts, onOpenAuth, onLogout, setFlash }) {
  const [selectedPackage, setSelectedPackage] = useState(gemPackages[2]);
  const [quantity, setQuantity] = useState(1);
  const [paymentMethod, setPaymentMethod] = useState(paymentMethods[0].key);
  const [playerId, setPlayerId] = useState("");
  const [username, setUsername] = useState(user?.fullName || "");
  const [contact, setContact] = useState(user?.phone || "");
  const [notes, setNotes] = useState("");
  const [file, setFile] = useState(null);
  const [submitting, setSubmitting] = useState(false);
  const [status, setStatus] = useState("");

  useEffect(() => {
    setUsername(user?.fullName || "");
    setContact(user?.phone || "");
  }, [user]);

  const selectedMethod = useMemo(() => paymentMethods.find((m) => m.key === paymentMethod) || paymentMethods[0], [paymentMethod]);
  const totalUsd = useMemo(() => selectedPackage.price * quantity, [selectedPackage, quantity]);
  const totalIqd = useMemo(() => Math.round(totalUsd * usdToIqd), [totalUsd, usdToIqd]);

  const saveProfile = () => {
    if (!user?.email) {
      setStatus(t.accountRequired);
      return;
    }
    const nextUser = { ...user, fullName: username, phone: contact };
    setUser(nextUser);
    try { localStorage.setItem(STORAGE_USER, JSON.stringify(nextUser)); } catch {}
    setFlash(t.createSuccess);
  };

  const submitOrder = (e) => {
    e.preventDefault();
    if (!playerId || !username || !contact) {
      setStatus(t.missingFields);
      return;
    }
    if (!file) {
      setStatus(t.missingFile);
      return;
    }
    setSubmitting(true);
    setStatus("");
    window.setTimeout(() => {
      const nextCount = orderCount + 1;
      setOrderCount(nextCount);
      try { localStorage.setItem(STORAGE_ORDER_COUNT, String(nextCount)); } catch {}
      setSubmitting(false);
      setStatus(t.success);
      setFile(null);
      setNotes("");
    }, 700);
  };

  return (
    <div className="page-shell">
      <GlobalStyles />
      <div className="glow g1" />
      <div className="glow g2" />
      <div className="glow g3" />
      <div className="container">
        <Header lang={lang} setLang={setLang} t={t} orderCount={orderCount} nowParts={nowParts} usdToIqd={usdToIqd} user={user} onOpenAuth={onOpenAuth} onLogout={onLogout} />

        <div className="main-grid">
          <div>
            <div className="panel">
              <div className="section-head">
                <div>
                  <h2 className="section-title">{t.packages}</h2>
                  <div className="section-sub">{t.packagesSub}</div>
                </div>
              </div>

              <div className="packages-grid">
                {gemPackages.map((pkg, index) => {
                  const active = selectedPackage.gems === pkg.gems;
                  return (
                    <motion.button
                      key={pkg.gems}
                      type="button"
                      className={`package-card ${active ? "active" : ""}`}
                      onClick={() => setSelectedPackage(pkg)}
                      initial={{ opacity: 0, y: 14 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: index * 0.05, duration: 0.25 }}
                    >
                      {pkg.popular ? <div className="pop-tag">{t.popular}</div> : null}
                      <div className="package-top">
                        <div style={{ display: "flex", gap: 14, alignItems: "center" }}>
                          <div className="gem-chip"><div className="gem-chip-inner"><Icon name="gem" className="gem-svg" /></div></div>
                          <div>
                            <div className="gem-count">{displayNumber(pkg.gems.toLocaleString(), lang)}</div>
                            <div className="gem-label">GEMS</div>
                            <div className={`bonus ${pkg.bonus ? "" : "muted"}`}>{pkg.bonus || t.noBonus}</div>
                          </div>
                        </div>
                        <div>
                          <div className="price-main">{formatMoney(pkg.price, lang, "USD")}</div>
                          <div className="price-sub">{t.perPack}</div>
                        </div>
                      </div>
                      <div className="package-actions">
                        <div className="qty-box" onClick={(e) => e.stopPropagation()}>
                          <button className="qty-btn" type="button" onClick={() => { setSelectedPackage(pkg); setQuantity((q) => Math.max(1, q - 1)); }}>−</button>
                          <div className="qty-num">{displayNumber(active ? quantity : 1, lang)}</div>
                          <button className="qty-btn" type="button" onClick={() => { setSelectedPackage(pkg); setQuantity((q) => Math.min(99, q + 1)); }}>+</button>
                        </div>
                        <div className="select-tag">{active ? t.selected : t.select}</div>
                      </div>
                    </motion.button>
                  );
                })}
              </div>
            </div>

            <div className="panel" style={{ marginTop: 18 }}>
              <div className="section-head">
                <div>
                  <h2 className="section-title">{t.orderFormTitle}</h2>
                  <div className="section-sub">{t.orderFormSub}</div>
                </div>
              </div>

              <form onSubmit={submitOrder}>
                <div className="inline-grid">
                  <div className="field"><label>{t.playerId}</label><input value={playerId} onChange={(e) => setPlayerId(e.target.value)} placeholder={t.playerId} /></div>
                  <div className="field"><label>{t.username}</label><input value={username} onChange={(e) => setUsername(e.target.value)} placeholder={t.username} /></div>
                  <div className="field"><label>{t.contact}</label><input value={contact} onChange={(e) => setContact(e.target.value)} placeholder={t.phone} /></div>
                  <div className="field"><label>{t.paymentMethod}</label><input value={selectedMethod.title} readOnly /></div>
                </div>

                <div className="field-grid" style={{ marginTop: 16 }}>
                  <div className="field"><label>{t.notes}</label><textarea rows={4} value={notes} onChange={(e) => setNotes(e.target.value)} placeholder={t.notesPlaceholder} /></div>
                  <label className="upload-box">
                    <input type="file" accept="image/png,image/jpeg,image/jpg" onChange={(e) => setFile(e.target.files?.[0] || null)} />
                    <div className="upload-icon-wrap"><Icon name="upload" /></div>
                    <div className="upload-text">{t.uploadText}</div>
                    <div className="upload-sub">{t.uploadSub}</div>
                    <div className="mini-btn" style={{ display: "inline-flex", marginTop: 16 }}>{t.chooseFile}</div>
                    {file ? <div className="file-name">{file.name}</div> : null}
                  </label>
                </div>
                <div style={{ marginTop: 18 }}><button className="submit-btn" type="submit" disabled={submitting}>{submitting ? t.submitting : t.submit}</button></div>
                {status ? <div className="status">{status}</div> : null}
              </form>
            </div>
          </div>

          <div className="right-grid">
            <div className="panel">
              <div className="section-head"><div><h2 className="section-title" style={{ fontSize: 24 }}>{t.orderReview}</h2><div className="section-sub">{t.reviewSub}</div></div></div>
              <div className="review-grid">
                <div className="review-line"><span className="review-label">{t.package}</span><span className="review-value">{displayNumber(selectedPackage.gems.toLocaleString(), lang)} Gems</span></div>
                <div className="review-line"><span className="review-label">{t.quantity}</span><span className="review-value">{displayNumber(quantity, lang)}</span></div>
                <div className="review-line"><span className="review-label">{t.paymentMethod}</span><span className="review-value">{selectedMethod.title}</span></div>
                <div className="review-line"><span className="review-label">{t.subtotal}</span><span className="review-value">{formatMoney(totalUsd, lang, "USD")}</span></div>
                <div className="review-line"><span className="review-label">{t.totalIqd}</span><span className="review-value">{formatMoney(totalIqd, lang, "IQD")}</span></div>
              </div>
              <div className="footer-note">{t.webhookInfo}</div>
            </div>

            <div className="panel">
              <div className="section-head"><div><h2 className="section-title" style={{ fontSize: 24 }}>{t.paymentTitle}</h2><div className="section-sub">{t.paymentSub}</div></div></div>
              <div className="payment-grid">
                {paymentMethods.map((method) => {
                  const logoSrc = method.key === "fib" ? "/fib-logo.webp" : "/fastpay-logo.png";
                  return (
                  <button key={method.key} type="button" className={`payment-card ${paymentMethod === method.key ? "active" : ""}`} style={{ background: method.accent }} onClick={() => setPaymentMethod(method.key)}>
                    <div className="payment-logo-row">
                      <img src={logoSrc} alt={method.title} className="pay-logo" />
                      <div style={{ minWidth: 0 }}>
                        <div className="method-title">{method.title}</div>
                        <div className="method-line">{displayNumber(method.number, lang)}</div>
                        <div className="rate-sub">{method.holder}</div>
                      </div>
                    </div>
                    <div className="payment-copy-row">
                      <button type="button" className="copy-btn" onClick={(e) => { e.stopPropagation(); navigator.clipboard?.writeText(method.number); setFlash(`${t.copy}: ${method.number}`); }}>{t.copy}</button>
                    </div>
                  </button>
                )})}
              </div>
            </div>

            <div className="panel">
              <div className="section-head"><div><h2 className="section-title" style={{ fontSize: 24 }}>{t.profileTitle}</h2><div className="section-sub">{t.profileSub}</div></div></div>
              <div className="field-grid">
                <div className="field"><label>{t.username}</label><input value={username} onChange={(e) => setUsername(e.target.value)} /></div>
                <div className="field"><label>{t.phone}</label><input value={contact} onChange={(e) => setContact(e.target.value)} /></div>
                <button className="mini-btn" type="button" onClick={saveProfile}>{t.saveProfile}</button>
              </div>
            </div>

            <div className="panel">
              <div className="section-head"><div><h2 className="section-title" style={{ fontSize: 24 }}>{t.notesTitle}</h2></div></div>
              <div className="note-grid">
                {t.noteCards.map(([title, desc]) => (
                  <div key={title} className="note-card">
                    <div className="note-title-row">
                      <div className="note-bullet"><Icon name="sparkle" /></div>
                      <div className="note-title">{title}</div>
                    </div>
                    <div className="note-desc">{desc}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function EventsPage({ lang, setLang, t, user, orderCount, usdToIqd, nowParts, onOpenAuth, onLogout }) {
  return (
    <div className="page-shell">
      <GlobalStyles />
      <div className="glow g1" />
      <div className="glow g2" />
      <div className="glow g3" />
      <div className="container">
        <Header lang={lang} setLang={setLang} t={t} orderCount={orderCount} nowParts={nowParts} usdToIqd={usdToIqd} user={user} onOpenAuth={onOpenAuth} onLogout={onLogout} />
        <section className="hero-shell" style={{ marginBottom: 20 }}>
          <div className="hero-grid">
            <div className="hero-left">
              <div className="brand-badge" style={{ width: "fit-content" }}><Icon name="sparkle" /> {t.navEvents}</div>
              <h1 className="hero-title">{t.eventsTitle}</h1>
              <p className="hero-text">{t.eventsText}</p>
              <div className="section-sub">{t.eventsSubText}</div>
            </div>
            <div className="hero-right">
              <img src="/events-banner.svg" alt="KonKan Events" className="hero-media" />
              <div className="hero-overlay" />
            </div>
          </div>
        </section>
        <section className="panel empty-state">
          <h2>{t.eventsTitle}</h2>
          <p>{t.eventsText}</p>
          <p style={{ marginTop: 16 }}>{t.eventsSubText}</p>
        </section>
      </div>
    </div>
  );
}

function HelpPage({ lang, setLang, t, user, orderCount, usdToIqd, nowParts, onOpenAuth, onLogout }) {
  const [openIndex, setOpenIndex] = useState(0);
  return (
    <div className="page-shell">
      <GlobalStyles />
      <div className="glow g1" />
      <div className="glow g2" />
      <div className="glow g3" />
      <div className="container">
        <Header lang={lang} setLang={setLang} t={t} orderCount={orderCount} nowParts={nowParts} usdToIqd={usdToIqd} user={user} onOpenAuth={onOpenAuth} onLogout={onLogout} />

        <section className="hero-shell" style={{ marginBottom: 20 }}>
          <div className="hero-grid">
            <div className="hero-left">
              <h1 className="hero-title">{t.helpTitle} <span className="accent">KonKan</span></h1>
              <p className="hero-text">{t.helpText}</p>
            </div>
            <div className="hero-right">
              <img src="/help-banner.svg" alt="KonKan Help" className="hero-media" />
              <div className="hero-overlay" />

            </div>
          </div>
        </section>

        <section className="panel">
          <div className="section-head">
            <div>
              <h2 className="section-title">{t.helpTitle}</h2>
              <div className="section-sub">{t.helpText}</div>
            </div>
          </div>
          <div className="faq-stack">
            {t.helpCategories.map((item, index) => {
              const isOpen = index === openIndex;
              return (
                <div className="faq-item" key={item.title}>
                  <button type="button" className="faq-head" onClick={() => setOpenIndex(isOpen ? -1 : index)}>
                    <span style={{ display: "flex", alignItems: "center", gap: 12, fontWeight: 800 }}><Icon name="sparkle" /> {item.title}</span>
                    <span style={{ transform: isOpen ? "rotate(90deg)" : "rotate(0deg)", transition: ".2s ease" }}><Icon name="chevron" /></span>
                  </button>
                  {isOpen ? <div className="faq-body">{item.body}</div> : null}
                </div>
              );
            })}
          </div>
        </section>
      </div>
    </div>
  );
}

export default function StoreApp({ page = "home" }) {
  const [lang, setLang] = useState(() => {
    if (typeof window !== "undefined") {
      try {
        return localStorage.getItem(STORAGE_LANG) || "en";
      } catch {}
    }
    return "en";
  });
  const [user, setUser] = useState(null);
  const [orderCount, setOrderCount] = useState(0);
  const [clock, setClock] = useState(new Date());
  const [authOpen, setAuthOpen] = useState(false);
  const [flash, setFlash] = useState("");
  const usdToIqd = useMemo(() => getDailyRate(new Date()), []);
  const nowParts = useMemo(() => getNowParts(lang), [clock, lang]);
  const t = content[lang];

  useEffect(() => {
    document.documentElement.dir = lang === "ku" ? "rtl" : "ltr";
    document.documentElement.lang = lang === "ku" ? "ku" : "en";
  }, [lang]);

  useEffect(() => {
    const timer = setInterval(() => setClock(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    try {
      const savedLang = localStorage.getItem(STORAGE_LANG);
      const savedUser = localStorage.getItem(STORAGE_USER);
      const savedCount = localStorage.getItem(STORAGE_ORDER_COUNT);
      if (savedLang) setLang(savedLang);
      if (savedUser) setUser(JSON.parse(savedUser));
      if (savedCount) setOrderCount(Number(savedCount) || 0);
    } catch {}
  }, []);

  useEffect(() => { try { localStorage.setItem(STORAGE_LANG, lang); } catch {} }, [lang]);
  useEffect(() => {
    if (!flash) return undefined;
    const timeout = setTimeout(() => setFlash(""), 2200);
    return () => clearTimeout(timeout);
  }, [flash]);

  const commonProps = { lang, setLang, t, user, setUser, orderCount, setOrderCount, usdToIqd, nowParts, onOpenAuth: () => setAuthOpen(true), onLogout: () => {
    setUser(null);
    try { localStorage.removeItem(STORAGE_USER); } catch {}
    setFlash(t.logoutSuccess);
  }, setFlash };

  return (
    <>
      <AnimatePresence mode="wait">
        <motion.div key={page} initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} transition={{ duration: 0.24 }}>
          {page === "shop" ? <ShopPage {...commonProps} /> : null}
          {page === "events" ? <EventsPage {...commonProps} /> : null}
          {page === "help" ? <HelpPage {...commonProps} /> : null}
          {page === "home" ? <HomePage {...commonProps} /> : null}
        </motion.div>
      </AnimatePresence>
      <AuthModal open={authOpen} onClose={() => setAuthOpen(false)} t={t} user={user} setUser={setUser} setFlash={setFlash} />
      {flash ? <div style={{ position: "fixed", bottom: 16, insetInlineStart: 16, zIndex: 90, padding: "12px 16px", borderRadius: 14, background: "rgba(203,157,32,.16)", color: "#fff1c4", border: "1px solid rgba(203,157,32,.22)" }}>{flash}</div> : null}
    </>
  );
}
